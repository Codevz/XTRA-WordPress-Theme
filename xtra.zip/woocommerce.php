<?php 

/**
 * 
 * Please note:
 * 
 * Core codes included in the functions.php file and you 
 * can find "generate_page" function inside functions.php
 * ---------
 * If you want to edit codes and also get automatic future updates, 
 * We recommend you first install both parent and child theme,
 * then activate child theme, then use WordPress or theme actions and filters
 * In this case your customization will remain on each theme or plugin updates.
 * 
 * WordPress Hooks: https://developer.wordpress.org/plugins/hooks/
 * 
 */

Codevz_Core_Theme::generate_page( 'woocommerce' );